(function addFooter() {
    const footer = document.createElement("footer");
    footer.className = "footer-custom";
    footer.innerHTML = `<p>&copy; 2025 MD Alquileres - Contáctanos al <strong>3153500149</strong></p>`;
    document.body.appendChild(footer);
})();
